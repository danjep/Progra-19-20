java --module-path mods -m launcher/launcher.Launcher
