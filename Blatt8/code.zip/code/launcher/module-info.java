module launcher {
    requires masterplan;
}