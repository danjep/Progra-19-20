package masterplan;

public class Masterarbeit extends LehrveranstaltungBase {

    public Masterarbeit(String title) {
        super(30, title, "Masterarbeit");
    }

}