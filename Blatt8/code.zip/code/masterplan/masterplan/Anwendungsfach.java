package masterplan;

public class Anwendungsfach extends LehrveranstaltungBase {

    public Anwendungsfach(int creditPoints, String title) {
        super(creditPoints, title, "Anwendungsfach");
    }

}