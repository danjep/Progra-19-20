package masterplan;

public class Seminar extends LehrveranstaltungMitBereichszuordnung {

    public Seminar(String title, Bereich field) {
        super(4, title, "Seminar", field);
    }

}