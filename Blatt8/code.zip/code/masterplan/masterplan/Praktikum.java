package masterplan;

public class Praktikum extends LehrveranstaltungBase {

    public Praktikum(String title) {
        super(7, title, "Praktikum");
    }

}