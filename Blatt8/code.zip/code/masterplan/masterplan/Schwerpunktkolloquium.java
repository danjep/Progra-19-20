package masterplan;

public class Schwerpunktkolloquium extends LehrveranstaltungBase {

    public Schwerpunktkolloquium(String title) {
        super(3, title, "Schwerpunktkolloquium");
    }

}