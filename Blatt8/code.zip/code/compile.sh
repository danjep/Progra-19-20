javac -d mods --module-source-path . launcher/launcher/Launcher.java
