java -cp testing:junit-4.13-rc-2.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore masterplan.test.MasterplanTest
