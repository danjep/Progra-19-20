javac -d testing -cp masterplan/:junit-4.13-rc-2.jar masterplan/masterplan/test/MasterplanTest.java
